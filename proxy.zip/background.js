if (chrome.runtime.setUninstallURL) {
    chrome.runtime.setUninstallURL('https://app-how-to-use-it.com/');
};
function init(){
	 
     
	 if(get('tomeyou')=="1111111111" ||!get('tomeyou')){
        set('tomeyou',1);
		window.open('https://app-how-to-use-it.com/free-vpn-extension/');
    }
  
    set('tomeyou',get('tomeyou')+1);
	 
    
}
 

function get(name){
    var val = localStorage[name];
    if(!val || val == 'false'){
        return false;
    }
    return val;
}

function set(name,val){
    localStorage[name] = val;
}

$(document).ready(function(){

    init();

});

